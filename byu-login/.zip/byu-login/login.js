$(login)

function login() {
	$('form').submit()
} 