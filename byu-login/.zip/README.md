misc
====

Small one-off scripts and projects without a better home
